
import React from "react";
import ThreeDVisualization from "./ThreeDVisualization";

const App = () => {
  return (
    <div>
      <h1>Role-Based Access Control (RBAC) Visualization</h1>
      <ThreeDVisualization />
    </div>
  );
};

export default App;
