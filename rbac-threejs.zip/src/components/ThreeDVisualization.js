
import React, { useEffect } from "react";
import * as THREE from "three";

const ThreeDVisualization = () => {
  useEffect(() => {
    // Set up the scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf4f4f9);

    // Set up the camera
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 5;

    // Set up the renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // Create roles (spheres)
    const rolesGeometry = new THREE.SphereGeometry(0.5, 32, 32);
    const rolesMaterial = new THREE.MeshStandardMaterial({ color: 0x007bff });
    const rolesMesh = new THREE.Mesh(rolesGeometry, rolesMaterial);
    rolesMesh.position.set(-2, 0, 0); // Position the role
    scene.add(rolesMesh);

    // Create users (nodes)
    const userGeometry = new THREE.SphereGeometry(0.3, 32, 32);
    const userMaterial = new THREE.MeshStandardMaterial({ color: 0x00ff7f });
    const userMesh = new THREE.Mesh(userGeometry, userMaterial);
    userMesh.position.set(2, 0, 0); // Position the user
    scene.add(userMesh);

    // Create a permission (line connecting role and user)
    const lineMaterial = new THREE.LineBasicMaterial({ color: 0xffa500 });
    const points = [];
    points.push(new THREE.Vector3(-2, 0, 0)); // Start point (role)
    points.push(new THREE.Vector3(2, 0, 0)); // End point (user)
    const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
    const line = new THREE.Line(lineGeometry, lineMaterial);
    scene.add(line);

    // Add lighting
    const light = new THREE.PointLight(0xffffff, 1, 100);
    light.position.set(10, 10, 10);
    scene.add(light);

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      rolesMesh.rotation.y += 0.01;
      userMesh.rotation.y += 0.01;
      renderer.render(scene, camera);
    };
    animate();

    // Clean up on unmount
    return () => {
      document.body.removeChild(renderer.domElement);
    };
  }, []);

  return <div />;
};

export default ThreeDVisualization;
